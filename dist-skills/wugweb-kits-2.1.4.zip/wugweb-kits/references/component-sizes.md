# Component sizes (copied from the doc)

Source: `kits_design_system/docs/tokens/sizing.md`, read 2026-11-17. The doc wins; if this differs, this copy is stale. Each row is a value to check against its token in `src/styles/global.css`.

| Component | Value | Token |
|---|---|---|
| Nav bar height | 68px (44 + 2 x 12), every breakpoint | `--nav-height` (derived) |
| Header height | 100px mobile, 108px tablet and desktop | `--header-height` (derived) |
| Nav button | 44px tall, 16px text, 10 12 padding, 12 gap | `--control-size` |
| Nav logo | 40px high, every breakpoint | `--nav-logo-height` |
| Mobile menu max | 100dvh (single scroll) | none |
| Pillar thumb | 88px (mobile 62px) | `--pillar-thumb`, `--pillar-thumb-sm` |
| Toggle chip | 44px | none named |
| Author photo | 56px circle | none named |
| Team photo | 1:1 aspect | none |
| Work and blog thumb | 16/10 aspect | none |
| Bento tile min height | 180px | `--bento-min` |
| Stat number | `--fluid-h3` | `--fluid-h3` |

`--pillar-thumb`, `--pillar-thumb-sm` and `--bento-min` are declared and no component references them with `var()` yet (2026-11-16). Toggle chip 44 and author photo 56 show no token in the doc and are not yet checked in code.

Icons: WhatsApp nav CTA 16px; toolkit icons between 16px and 18px; bento stack icons 18px; logo lockup 149 x 54 and mark 54 x 54 (SVG intrinsic).

## Logo sizes (owner rulings via wugweb-brand-os, f66bb666, 2026-11-17)

The logo rules and the logo checks (files, tones, exemptions, ground) are owned by `wugweb-brand-os`: `.claude/skills/wugweb-brand-os/SKILL.md` and `.claude/skills/wugweb-brand-os/references/visual-os/art-direction.md`, Logo section. Kits holds only the two sizes below and checks them.

| Value | Rule |
|---|---|
| Minimum size | 40px high, the nav logo (`--nav-logo-height`), is the floor |
| Clear space | on every side, equal to the rendered height of the mark; the mark is as tall as the lockup (54 of 54), so at 40px the clear space is 40px |

Open clash, for brand-os and the owner: in the nav the 40px logo sits in a 68px bar with a 12px bar inset, so it has 14px above and below, not 40. Kits reports it and does not change the nav.

## Sizes confirmed by the owner, 2026-11-17

These four are confirmed by the owner and are in `sizing.md`, section "Rail, signature and line length" (read 2026-11-19). The doc stays the source.

| Item | Value |
|---|---|
| Rail width | 85vw, never wider than the 1200 content max on desktop |
| Rail peek | 20% |
| Signature width | 2400px |
| Line length | 35 to 60 characters |

Token names approved by the owner 2026-11-17, added to `global.css` on 2026-11-17 on the owner's go: `--rail-width: min(85vw, 1200px)`, `--rail-peek: 20%`, `--signature-width: 2400px`, `--measure-min: 35ch`, `--measure-max: 60ch`.

## Made-file sizes adopted by the owner, 2026-11-17

Relayed through the coordinating session from the `wugweb-seo` rulings. Source is the owner, not a design doc.

| File | Size |
|---|---|
| Og image | 1200 x 630, key content in the central 80% |
| LinkedIn link image | 1200 x 627 minimum |
| Behance cover | 808 x 632 minimum |
| Dribbble | 1600 wide |
| Story | 1080 x 1920 (official). No official pixel figure for the safe zone: keep the top, bottom and sides free of key elements, text and logos, and the bottom 40% free of text on Reels ads (Meta Business Help Center, read by wugweb-seo 2026-11-17) |

## Card thumbnails, owner 2026-11-17

One thumbnail ratio, 16/10, on every card, not only work and blog. The original file ratio is kept and the 16/10 frame is a mask on the page. Old Framer media ratios are closed (owner, 2026-11-17): not mapped.

## Deck and card type sizes, owner approved 2026-11-17

Kits proposed these from the existing site scale and the owner approved. No new token; the three graphic tokens scale with their container (container query units), so they fit any made-file size.

| Role on a deck slide or card | Token | Range |
|---|---|---|
| Title | `--type-graphic-l` | 4rem to 12rem, 14% of container width |
| Subtitle or key figure | `--type-graphic-m` | 2.5rem to 7rem, 9% |
| Label or tag | `--type-graphic-s` | 1.75rem to 4rem, 6% |
| Body text | `--fluid-body-md`, `--fluid-body-sm` | unchanged |

The element that holds the text must be a size container (`container-type: inline-size`). Only `--type-graphic-s` is used in code today (`ServiceTagField`); all three are in `typography.md` (2026-11-17).
