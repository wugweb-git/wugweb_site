# Words

Lists that `scripts/check.mjs` reads are the fenced blocks below. Change a list here only; nothing else holds a copy.

Labels: confirmed (owner said or approved, with date), observed (from samples, with IDs and count), candidate (found in a document, not ruled on). Only confirmed and observed entries are flagged by the check. Candidates are reported as questions.

## Dashes (confirmed, owner standing rule)

No em dash and no en dash in visible copy. Write ranges out: "3 to 5", not `3-5`. The check also flags a spaced hyphen used as a dash (`a - b`).

## Spelling (confirmed: British English, owner standing rule)

The pairs below are mechanical spelling, not voice. Format: `us = british`. Add pairs as they turn up.

```spelling
color = colour
colors = colours
colored = coloured
favorite = favourite
behavior = behaviour
behaviors = behaviours
organization = organisation
organizations = organisations
organize = organise
organized = organised
centralize = centralise
centralized = centralised
optimize = optimise
optimized = optimised
optimization = optimisation
prioritize = prioritise
prioritized = prioritised
customize = customise
customized = customised
realize = realise
recognize = recognise
analyze = analyse
analyzed = analysed
utilize = use
center = centre
centers = centres
program = programme
programs = programmes
catalog = catalogue
dialog = dialogue
license = licence
defense = defence
traveling = travelling
modeling = modelling
labeled = labelled
canceled = cancelled
gray = grey
```

Note: `program` stays as it is for software code. The check flags it; the reader decides.

## Banned words (confirmed)

Empty. "No filler words" is a confirmed owner rule, but he has not yet ruled on which words. Entries move here from the candidate list only with his yes.

```banned-confirmed
```

## Banned words (candidate, waiting on the owner's ruling)

Source: the draft "Writing style and tone" section of `docs/skills/wugweb-work/PLAN.md` (section 5), written from his decisions but not yet reviewed by him as his voice. Not flagged; reported as questions. In a rewrite or a proposed change, leave candidate and unruled words in place and ask the owner; never drop or replace a word as filler on your own judgment.

```banned-candidate
pivotal
robust
seamless
meticulous
holistic
cutting-edge
leverage
empower
unlock
world-class
sophisticated
state-of-the-art
game-changing
```

Also named as words to avoid, with "seamless", in the digital-twin plan document the owner supplied on 2026-11-19 (`digital-twin-source.md`): "state-of-the-art" and "game-changing". Added to the candidate list above on that source. They are candidates like the rest: reported as questions, never removed from a draft.

## Preferred terms

Waiting on samples.

## Proper nouns and terms kept as written

Used by the heading-case check so these are not flagged. Client terms are kept exactly as the client writes them.

```proper-nouns
Wugweb
British
English
Vedanshu
NTUC
iCube
LinkedIn
Behance
Dribbble
Notion
Sanity
Cloudflare
GPT
Cursor
Claude
```
