---
name: wugweb-engineer
description: "This skill should be used when the user asks to \"change a Sanity field\", \"patch these posts\", \"fix the data in Sanity\", \"run the Notion sync\", \"sync the blogs from Notion\", \"back up before the change\", \"undo that Sanity change\", \"check the schema against the data\", \"add or remove a field in the schema\", \"which scripts are safe to run\", or \"list what is in R2\" for the Wugweb site, or mentions Sanity documents, the Notion to Sanity sync scripts, backups, schemaType values, faqs fields or the asset registry. It governs Sanity and Notion data changes end to end: read, back up, dry run, a one-field patch on the owner's go, check and undo, plus Sanity schema edits and the script status list. Use it for any change to stored Wugweb content data, even when the user only says \"fix it in the CMS\". It writes no copy, sets no SEO or content rules, and does not cover deploy, build or git, which stay in the repo's AGENTS.md."
license: MIT
metadata:
  author: wugweb
  version: "0.3.2"
  status: "built 2026-11-19, named wugweb-engineer by the owner and registered in the Notion registry as row 7 the same day"
---

# wugweb-engineer

Govern every change to the data behind wugweb.com: Sanity documents, the Sanity schema, the Notion to Sanity sync scripts, backups and undo. Make each change small, visible and reversible, and make none without the owner's go on that exact change.

The site reads Sanity (project `splvhmk1`, dataset `production`). Notion is the source for case studies and blog posts and reaches Sanity through three sync scripts. Media lives in R2 and is read here, never written. Sessions have repeatedly needed the same procedure (dry run, backup, one-field patch, check, undo); this skill writes it down once so that it runs the same way every time and in any tool.

## Read first

1. The owner's standing rules: `docs/skills/STANDING-RULES.md` in the repo. They win over anything here. A marked copy is built into `AGENTS.md` and `export/wugweb-engineer.md` for tools that cannot open the repo.
2. `docs/skills/SECRETS.md` for key names and handling, and `references/tooling.md` for project ids, variable names and which connector or script reaches each system.
3. The reference named by the mode below.

## What this skill owns

| Owns | Does not own (goes to) |
|---|---|
| Patches to Sanity and Notion data, and their backups and undo | What a page says: `wugweb-work` |
| Edits to the Sanity schema files in `sanity/schemaTypes/` | Which schema type, title or markup a page uses: `wugweb-seo` sets it, this skill applies it |
| Running and checking the Notion to Sanity sync scripts | Which fields a content type should have: `wugweb-strategy` decides, this skill builds |
| The schema against data check | Tokens, layout and block docs: `wugweb-kits` |
| The script status list for `scripts/` | Deploy, build, previews and git: the repo's `AGENTS.md` |
| Read-only R2 listing and media weight facts | Making, moving or removing media: nobody without the owner |

When a request touches both columns, do this skill's part and name the other skill for the rest. Never write the other skill's rule here.

## Modes

Pick one mode per request. Say which mode is running in the first line of the reply.

| Mode | When | Reference |
|---|---|---|
| Read | "what does Sanity hold for", counts, a field's values | `references/data-patch-runbook.md` (step 1) |
| Plan a change | any request to change stored data | `references/data-patch-runbook.md` |
| Apply | only after the owner says go to a shown plan | `references/data-patch-runbook.md` (steps 6 to 8) |
| Undo | "undo", "restore", "put it back" | `references/data-patch-runbook.md` (undo) |
| Schema change | add, rename, hide or remove a field or option | `references/schema-change.md` |
| Sync | "run the Notion sync", "pull the blogs from Notion" | `references/sync-scripts.md` |
| Schema check | "check the schema against the data", undeclared fields | `references/schema-change.md` (check) |
| Script check | "is this script safe", "what can I run" | `references/script-status.md` |
| Media read | "list what is in R2", folder sizes, missing files | `references/media-read.md` |

## The data-change procedure

Every change to stored data follows these steps in order. Stop at the first step that fails and report it.

1. **Read.** Query the documents the change touches, published and draft. Count them. Report the count before anything else, computed, never estimated.
2. **Back up.** Run `scripts/backup.mjs` with the same query. It writes `backups/<label>-<timestamp>.json` with the query, the count, each document's `_id` and `_rev`, and a SHA-256 of the contents. It refuses to overwrite a file.
3. **Plan.** Run `scripts/plan-patch.mjs` on that backup with the field and the new value, or with `--values` when each document gets its own value. It writes a plan file and prints a table: document, field, current, proposed. A document whose current value already equals the proposed one is listed as "no change" and left out of the writes.
4. **Show.** Give the owner the table, the count, the backup path, what the change touches on the live site (visible or not), and the undo. Use the change report format below.
5. **Wait.** Do nothing more until the owner says go to that plan. A go to an earlier plan, a similar plan or "the data fixes" in general is not a go to this one; ask.
6. **Apply.** Run `scripts/apply-plan.mjs --go` on the plan file. It checks that the backup exists and matches its hash, sends only `patch` mutations with `set` or `unset` on the planned field, each guarded by `ifRevisionID` so a concurrent Studio edit fails instead of being overwritten, and writes a result log. It refuses any plan holding a delete, a create, a whole-document replace or a field not named in the plan.
7. **Check.** Read the documents again and compare with the plan. Every planned value present, every other field unchanged. If the change shows on a page, request that page twice on staging and confirm 200 both times.
8. **Record.** Report the result log path, the counts (planned, written, skipped by revision clash) and the undo command.

### Rules for the procedure

- Patch one field per plan. Two fields means two plans, two tables, two goes, unless the owner asks for them together.
- Never send `createOrReplace`, `create`, `delete` or `discardDraft` from this skill: the skill itself never creates a document. The one exception is the blog sync script's own create-if-missing, run only on the owner's go (`references/sync-scripts.md`). Any other request that needs one goes to the owner as a proposal with its own backup and an owner-run script, the pattern of the `owner-delete-*` scripts.
- Never clear a field because the source is empty. An empty Notion value leaves Sanity alone.
- Patch drafts and published documents alike when both exist, so Studio does not show a stale draft over the change.
- Keep stored values that nothing reads unless the owner rules otherwise. "Unused" is a finding, not a reason to unset.
- A revision clash on apply is a stop: report which documents clashed, take a new backup, re-plan, and ask again.

## Schema changes

A schema edit changes what Studio shows and validates; it never changes stored data. Removing a field from the schema leaves its values in the documents. Follow `references/schema-change.md`: one branch, the edit, `npm run build` and `npm run test:sanity`, the Studio build in `sanity/`, a local Studio look, then the owner's merge and the owner's Studio deploy. Never remove `blockContent` from the types array. A schema change that implies a data change (backfill, clean-up) gets its own data-change plan.

## Sync scripts

The three Notion to Sanity scripts dry run by default and write with `WRITE=1`, backing up first. Run the dry run, show the plan it prints, and run the write only on the owner's go. Before any run, check the Notion token: a 401 means stop and tell the owner the token needs replacing. Never write to Notion from a sync. Details per script are in `references/sync-scripts.md`.

## Scripts in the site repo

`scripts/` in the site repo holds about fifty scripts written by many sessions. Their write switches differ: some dry run unless `WRITE=1` or `APPLY=1`, some write unless `DRY_RUN=1`, and some write with no switch at all. Before running any of them, look it up in `references/script-status.md`, and re-run `scripts/scan-scripts.mjs` when the folder has changed since the table's date. Never run a script marked "do not run" or "owner only"; a script not in the table counts as "do not run" until scanned.

## Change report format

Use this shape for every plan shown to the owner:

```
Change: <one line, plain>
Mode: Plan a change
Touches: <type>, <field>, <N> documents (<n> published, <n> drafts); visible on the site: yes or no
Backup: backups/<file>.json (<N> documents, sha256 <first 12>)
Plan: backups/<file>.plan.json

| Document | Field | Current | Proposed |
|---|---|---|---|
| post-example | schemaType | TechArticle | BlogPosting |

No change: <n> documents already hold the proposed value.
Undo: take a fresh backup, then node scripts/plan-patch.mjs --backup <fresh> --field <field> --restore <backup>, and apply on the owner's go.
Waiting for: your go on this plan.
```

Show every row when there are 30 or fewer; above that, show the first 10, the counts by current value, and the plan file path.

## Worked example

Request: "seo says posts should be BlogPosting, switch the 19 TechArticle posts over."

1. Name the mode: Plan a change. Name the owners: `wugweb-seo` set the value; this skill applies it.
2. Read `*[_type == "post" && schemaType == "TechArticle"]` and report the real count, drafts included. If it is not 19, say so.
3. Back up those documents, plan `schemaType` to `"BlogPosting"`, and show the change report: no visible change, because no page reads `schemaType` today.
4. Stop. On the owner's go, apply, read the documents again, and report written, clashed and the undo.

The request said "now", but "now" is not a go to a plan the owner has not seen. Show the plan first; it costs one message and keeps the change reversible.

## Handoffs

- From `wugweb-seo`: schema type and markup rules, and which value a field should hold. Apply them; never choose them.
- From `wugweb-strategy`: decisions on which fields exist and which stored values stay. Build them; never decide them.
- From `wugweb-work`: approved Body Content and the request to sync it. Run the sync; never edit the content.
- To all of them: plans, backups, change reports and check results.
- To `wugweb-kits`: nothing directly. A schema field that drives a block is named in the change report so `wugweb-work` can pass it on.

The full contracts, with what each side gives and takes, are in `references/handoffs.md`.

## When the request is unclear

- No exact field, value or document set: read and report what exists, then ask which change is meant.
- The change would delete, create or replace documents: say so, plan it as a proposal only, and name the owner-run route.
- The change sits in another skill's column: say which skill owns it and stop there.
- Not decided: say "not decided" and name who decides, usually the owner or the skill in the table above.

## Additional resources

### Reference files

- `references/data-patch-runbook.md`: the procedure step by step with commands, the undo, and a worked example.
- `references/schema-change.md`: editing schema files, the schema check, and what never to remove.
- `references/sync-scripts.md`: the three Notion to Sanity scripts, their switches, backups and failure modes.
- `references/script-status.md`: every script in the site's `scripts/` folder with its switch and status.
- `references/media-read.md`: reading R2 and the asset registry without writing.
- `references/handoffs.md`: contracts with the other Wugweb skills.
- `references/tooling.md`: ids, environment variables, connectors and the plain HTTP calls the scripts use.
- `references/open-items.md`: the pending data and schema items from the engineering page, and how each runs here.

### Scripts (plain Node 18 or later, no packages)

- `scripts/backup.mjs`: query Sanity and write a hashed backup.
- `scripts/plan-patch.mjs`: build a one-field plan (one value, per-document values, or an undo from a backup).
- `scripts/apply-plan.mjs`: apply a plan on `--go`, patches only, with revision guards.
- `scripts/schema-fields.mjs`: list declared fields per type; with `--data`, list stored keys the schema does not declare.
- `scripts/scan-scripts.mjs`: classify the site's scripts by their write switch.
- `scripts/validate.mjs`, `scripts/test.mjs`, `scripts/build.mjs`: checks for this skill and the single-file export.

### Examples and tests

- `examples/`: an invented backup, a one-value plan, a per-document values plan and the change report they produce.
- `evals/`: six test cases and a 20-prompt routing check, kept in the repo and the full zip and left out of the installed `.skill` package. Each must pass before a new version is handed to the owner.
